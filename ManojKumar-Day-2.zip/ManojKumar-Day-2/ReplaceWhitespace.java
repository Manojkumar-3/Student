package basics1;

public class ReplaceWhitespace {

	public static void main(String[] args) {
		
		 String Str = new String("Animes contain all types of emotion in them");
	      System.out.print("Without spaces :" );
	      System.out.println(Str.replaceAll(" ", ""));

	}

}
