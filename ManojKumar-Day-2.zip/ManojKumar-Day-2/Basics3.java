package basics1;

public class Basics3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=3;
		System.out.println(a++);
		System.out.println(a--);
		System.out.println(++a);
		System.out.println(--a);

	}

}
