package basics1;

public class Basics_4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=2;
		int b=3;
		if(a>b)
			
		{
			System.out.println("a is greater");
			
		}
		else 
		{
			System.out.println("b is greater");
		}
			

	}

}
