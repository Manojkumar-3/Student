package basics1;

public class LowertoUpper {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="crash landing",str1="REINCARINATED AS SLIME";    
        System.out.println("The String is: "+str);
        
       
        str=str.toUpperCase(); 
        str1=str1.toLowerCase();
       System.out.println("Lower case to Upper :"+str);
       System.out.println("Upper case to Lower :"+str1);

	}

}
